//var footer = jQuery('footer .site-info');
//var field = jQuery('div#customize-control-footer_text textarea');

// jQuery('div#customize-control-footer_text textarea').keyup(function($) {
//     $('footer .site-info').html($(this).val());
// });
